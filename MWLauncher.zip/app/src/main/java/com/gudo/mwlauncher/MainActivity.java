package com.gudo.mwlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;

public class MainActivity extends Activity {
    private static final String[] CHECKLIST = {
        "Graphics driver: Vortek if available (not Turnip)",
        "DirectX wrapper: DXVK 1.10.3 (try WineD3D if it crashes)",
        "Resolution: 1280x720 (960x540 if laggy)",
        "Box64 preset: Compatibility first, then Performance",
        "FPS cap: 30",
        "In-game graphics: lowest",
        "Close background apps and keep the phone cool"
    };

    private SharedPreferences prefs;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("launcher", MODE_PRIVATE);
        ScrollView scroll = new ScrollView(this);
        scroll.setFitsSystemWindows(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root);
        setContentView(scroll);
        draw();
    }

    private void draw() {
        root.removeAllViews();
        text("MOUTHWASHING LAUNCHER", 24);
        text("Unofficial. Opens your emulator; the game is not included.", 14);

        String chip = Build.HARDWARE;
        if (Build.VERSION.SDK_INT >= 31) chip = Build.SOC_MANUFACTURER + " " + Build.SOC_MODEL;
        String lower = chip.toLowerCase(java.util.Locale.ROOT);
        boolean mtk = lower.contains("mediatek") || lower.startsWith("mt");
        text("Chip: " + chip + (mtk ? " (MediaTek detected)" : " (MediaTek not detected)"), 14);

        String name = prefs.getString("name", null);
        button(name == null ? "PLAY (choose emulator first)" : "PLAY with " + name, v -> play());
        button("Choose emulator", v -> choose());

        text("Set these inside your emulator (starting points):", 16);
        for (int i = 0; i < CHECKLIST.length; i++) {
            String key = "check" + i;
            CheckBox box = new CheckBox(this);
            box.setText(CHECKLIST[i]);
            box.setChecked(prefs.getBoolean(key, false));
            box.setOnCheckedChangeListener((b, on) -> prefs.edit().putBoolean(key, on).apply());
            root.addView(box);
        }
    }

    private void text(String value, int size) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(size);
        view.setPadding(0, 12, 0, 12);
        root.addView(view);
    }

    private void button(String label, View.OnClickListener action) {
        Button b = new Button(this);
        b.setText(label);
        b.setOnClickListener(action);
        root.addView(b);
    }

    private void choose() {
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> apps = pm.queryIntentActivities(query, 0);
        apps.removeIf(a -> a.activityInfo.packageName.equals(getPackageName()));
        apps.sort((a, b) -> a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()));
        CharSequence[] labels = new CharSequence[apps.size()];
        for (int i = 0; i < labels.length; i++) labels[i] = apps.get(i).loadLabel(pm);
        new AlertDialog.Builder(this)
            .setTitle("Pick Winlator or GameHub")
            .setItems(labels, (d, i) -> {
                prefs.edit()
                    .putString("name", labels[i].toString())
                    .putString("pkg", apps.get(i).activityInfo.packageName)
                    .apply();
                draw();
            })
            .show();
    }

    private void play() {
        String pkg = prefs.getString("pkg", null);
        if (pkg == null) { choose(); return; }
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            Toast.makeText(this, "Emulator not found. Choose it again.", Toast.LENGTH_LONG).show();
            return;
        }
        startActivity(launch);
    }
}
