# MW Launcher (unofficial)
Opens your emulator for your own copy of Mouthwashing. Not yet built or tested on a device.

## Build with Android Studio
Open this folder, let it sync, then Build > Build APK(s).
If asked for a Gradle version, use 8.7.

## Build with GitHub (no Android Studio)
1. Create a repository and upload the CONTENTS of this folder, including .github.
2. Open the Actions tab and run "Build APK".
3. Download mw-launcher-apk, unzip it, and install the APK.

## Use
Tap "Choose emulator", pick Winlator or GameHub, then tap PLAY.
Start the game from inside the emulator.
